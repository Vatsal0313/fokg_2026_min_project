from rdflib.term import Literal
from .graph_loader import load_rdf


def get_type(uri):

    uri = str(uri).lower()

    if "person" in uri:
        return "person"

    if "project" in uri:
        return "project"

    if "publication" in uri:
        return "publication"

    if "group" in uri:
        return "group"

    return "default"


def short_uri(uri):

    uri = str(uri)

    if "#" in uri:
        return uri.split("#")[-1]

    return uri.split("/")[-1]


def build_graph():

    rdf = load_rdf()

    nodes = {}
    edges = []

    labels = {}

    # -------------------------
    # Build readable labels
    # -------------------------
    for s, p, o in rdf:

        if not isinstance(o, Literal):
            continue

        pred = str(p)

        if pred.endswith("#name"):
            labels[str(s)] = str(o)

        elif pred.endswith("#title"):

            if str(s) not in labels:
                labels[str(s)] = str(o)

    count = 0

    # -------------------------
    # Build graph
    # -------------------------
    for s, p, o in rdf:

        if isinstance(o, Literal):
            continue

        s = str(s).strip()
        o = str(o).strip()

        if not s or not o:
            continue

        count += 1

        if count > 1000:
            break

        if s not in nodes:

            nodes[s] = {
                "data": {
                    "id": s,
                    "label": labels.get(s, short_uri(s)),
                    "type": get_type(s)
                }
            }

        if o not in nodes:

            nodes[o] = {
                "data": {
                    "id": o,
                    "label": labels.get(o, short_uri(o)),
                    "type": get_type(o)
                }
            }

        edge_label = short_uri(p)

        edges.append({
            "data": {
                "source": s,
                "target": o,
                "label": edge_label
            }
        })

    return list(nodes.values()) + edges