from django.urls import path
from . import views

urlpatterns = [
    path("", views.graph_view),
    path("api/graph/", views.graph_data),
    path(
        "",
        views.graph_view,
        name="graph"
    ),

    path(
        "api/graph/",
        views.graph_data,
        name="graph-data"
    )
]