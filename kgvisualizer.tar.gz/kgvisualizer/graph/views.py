from django.http import JsonResponse
from django.shortcuts import render
from .utils import build_graph

def graph_data(request):

    data = build_graph()

    return JsonResponse(
        data,
        safe=False
    )


def graph_view(request):

    return render(
        request,
        "graph/index.html"
    )