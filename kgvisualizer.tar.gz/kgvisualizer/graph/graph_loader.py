from rdflib import Graph

def load_rdf():

    g = Graph()

    g.parse(
        "data/aifbfixed_complete.n3",
        format="n3"
    )

    return g